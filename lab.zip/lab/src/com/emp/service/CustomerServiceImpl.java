package com.emp.service;

import java.util.List;

import com.emp.bin.CustomerBean;
import com.emp.bin.MobileBean;
import com.emp.dao.CustomerDao;
import com.emp.dao.CustomerDaoImpl;
import com.emp.exception.MobileException;

public class CustomerServiceImpl implements CustomerService{

	
	
	public int addCustomer(CustomerBean custbean) throws  MobileException{
		
		CustomerDao obj=new CustomerDaoImpl();
		int pid=obj.addCustomer(custbean);
		return pid;
	}
	
	public List<MobileBean>viewAllMobiles() throws MobileException{
		
		CustomerDao obj=new CustomerDaoImpl();
		MobileBean mblbean  =new MobileBean();
		List<MobileBean> MblList=obj.viewAllMobiles();
		return MblList;
	}
	
	public int deleteMob(int id) throws MobileException{
		CustomerDao obj=new CustomerDaoImpl();
		id=obj.deleteMob(id);
		return id;
		
		
	}
	}

