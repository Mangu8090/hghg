package com.emp.pl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.emp.bin.CustomerBean;
import com.emp.bin.MobileBean;
import com.emp.exception.MobileException;
import com.emp.service.CustomerService;
import com.emp.service.CustomerServiceImpl;


public class Mobile {

public static void main(String[] args) {
	

        int n1;
		do{
		System.out.println("1.add customer details");
	   System.out.println("2.view all mobile details");
	  System.out.println("3.delete mobile by id");
	  System.out.println("4.search mobile based on range");
	System.out.println("Enter choice");
	Scanner sc= new Scanner(System.in);
						
	int n= sc.nextInt();
	switch(n)
	{
	case 1:
		System.out.println("Enter customer name");
		String cname= sc.next();
		System.out.println("Enter customer email");
		String mailid= sc.next();
		System.out.println("Enter customer contact");
		String phoneno= sc.next();
		System.out.println("Enter mobileid");
		int mobileid= sc.nextInt();
		
		
		CustomerBean custbean=new CustomerBean();
		custbean.setCname(cname);
		custbean.setMailid(mailid);
		custbean.setPhoneno(phoneno);
		custbean.setMobileid(mobileid);				
			
		CustomerService service=new CustomerServiceImpl();
		try{
			//if(service.validateEmployee(bean)){
		int id=service.addCustomer(custbean);
		System.out.println("id added is="+id);
			}
			//else
			//{
			//	throw new MobileException("enter valid details");
			//}
	//}
		catch (MobileException e) 
		{	
			e.printStackTrace();
			System.out.println("pid can't be generated");
		}
	  break;
	  
	case 2:
		CustomerService service1=new CustomerServiceImpl();
		try {
			List<MobileBean> MblList = new ArrayList<MobileBean>();
			MblList = service1.viewAllMobiles();
				Iterator<MobileBean> i = MblList.iterator();
				while (i.hasNext()) {
					System.out.println(i.next());
				}
			} catch(MobileException e)
			{
				e.printStackTrace();

			}
		break;
		
	case 3:
		System.out.println("Enter id you want to delete");
		CustomerService service2=new CustomerServiceImpl();
		
		int id=sc.nextInt();
		try{
			
		id=service2.deleteMob(id);
		System.out.println("id deleted"+id);
		
		}
		catch(MobileException e)
		{
			System.out.println(e.getMessage());
		}
		break;
	}System.out.println("Do you want to continue\n1.yes2.no");
	Scanner sc1= new Scanner(System.in);
	n1=sc1.nextInt();
	}
	while(n1==1);
	}					
						}